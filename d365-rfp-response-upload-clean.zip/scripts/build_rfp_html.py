#!/usr/bin/env python3
"""Build a D365 RFP response HTML summary from an Excel workbook.

Usage:
    python scripts/build_rfp_html.py path/to/rfp.xlsx -o output.html --title "D365 RFP Response"
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime
from html import escape
from pathlib import Path
from typing import Iterable, List, Sequence

try:
    from openpyxl import load_workbook
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "Missing dependency: openpyxl. Install it with: pip install openpyxl"
    ) from exc


REQUIRED_COLUMNS = {
    "id": ["id", "ref", "item ref", "requirement_id", "requirement no", "item id", "item", "code", "reference"],
    "category": ["category", "domain", "group", "section", "theme"],
    "requirement": ["requirement", "requirement description", "description", "question", "detail", "details", "response requirement", "item description"],
    "priority": ["priority", "importance", "criticality", "impact"],
    "status": ["status", "response status", "completion", "state"],
    "owner": ["owner", "responsible team", "team", "assigned to"],
    "notes": ["notes", "comments", "assumptions", "remarks", "response notes"],
}


def normalize_key(value: object) -> str:
    text = "" if value is None else str(value).strip()
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()


def cell_to_text(value: object) -> str:
    if value is None:
        return ""
    return str(value).strip()


def find_header_row(rows: Sequence[Sequence[object]]) -> int:
    for idx, row in enumerate(rows):
        normalized = [normalize_key(cell) for cell in row]
        matches = sum(1 for c in normalized if any(c in alias for alias in [
            "id", "requirement", "category", "priority", "status", "notes", "owner", "description"
        ]))
        if matches >= 2:
            return idx
    return 0 if rows else -1


def match_column(headers: Sequence[str], candidates: Sequence[str]) -> int:
    map_index = {normalize_key(h): idx for idx, h in enumerate(headers)}
    for candidate in candidates:
        if normalize_key(candidate) in map_index:
            return map_index[normalize_key(candidate)]
    return -1


def row_is_empty(row: Sequence[object]) -> bool:
    return all(cell_to_text(cell) == "" for cell in row)


def coerce_priority(value: object) -> str:
    text = (value or "").strip().lower()
    if not text:
        return "Unspecified"
    if text.startswith("high"):
        return "High"
    if text.startswith("medium") or text.startswith("med"):
        return "Medium"
    if text.startswith("low"):
        return "Low"
    if text.startswith("mandatory") or text.startswith("must") or text.startswith("critical"):
        return "High"
    return text.title()


def extract_requirements(workbook_path: str):
    wb = load_workbook(workbook_path, data_only=True)
    all_rows = []
    for sheet in wb.worksheets:
        rows = list(sheet.iter_rows(values_only=True))
        if not rows:
            continue
        header_idx = find_header_row(rows)
        if header_idx < 0:
            continue
        headers = [cell_to_text(cell) for cell in rows[header_idx]]
        column_map = {key: match_column(headers, candidates) for key, candidates in REQUIRED_COLUMNS.items()}
        for row in rows[header_idx + 1 :]:
            if row_is_empty(row):
                continue
            requirement = {
                "sheet": sheet.title,
                "id": cell_to_text(row[column_map["id"]]) if column_map["id"] >= 0 and column_map["id"] < len(row) else "N/A",
                "category": cell_to_text(row[column_map["category"]]) if column_map["category"] >= 0 and column_map["category"] < len(row) else "General",
                "requirement": cell_to_text(row[column_map["requirement"]]) if column_map["requirement"] >= 0 and column_map["requirement"] < len(row) else "",
                "priority": coerce_priority(row[column_map["priority"]]) if column_map["priority"] >= 0 and column_map["priority"] < len(row) else "Unspecified",
                "status": cell_to_text(row[column_map["status"]]) if column_map["status"] >= 0 and column_map["status"] < len(row) else "Open",
                "owner": cell_to_text(row[column_map["owner"]]) if column_map["owner"] >= 0 and column_map["owner"] < len(row) else "TBC",
                "notes": cell_to_text(row[column_map["notes"]]) if column_map["notes"] >= 0 and column_map["notes"] < len(row) else "",
            }
            if requirement["requirement"]:
                all_rows.append(requirement)

    if not all_rows:
        raise ValueError("No requirement rows detected. Check the workbook for requirement IDs and descriptions.")

    categories = Counter(r["category"] for r in all_rows)
    priorities = Counter(r["priority"] for r in all_rows)
    status_counts = Counter(r["status"] for r in all_rows)
    sheets = sorted({r["sheet"] for r in all_rows})
    return {
        "title": Path(workbook_path).stem.replace("_", " ").replace("-", " ").title(),
        "generated_at": datetime.now().strftime("%d %b %Y"),
        "req_count": len(all_rows),
        "categories": categories,
        "priorities": priorities,
        "status_counts": status_counts,
        "sheets": sheets,
        "requirements": all_rows,
    }


def requirement_group_rows(requirements: Iterable[dict]) -> list[dict]:
    grouped = defaultdict(list)
    for row in requirements:
        grouped[row["category"]].append(row)
    return [{"category": key, "items": value} for key, value in sorted(grouped.items(), key=lambda item: item[0].lower())]


SOLUTION_ARCHITECTURE_MERMAID = """flowchart LR
    Users[Business users and proposal team] --> Channels[Copilot Studio / web report / review pack]
    Channels --> Identity[Microsoft Entra ID and role-based access]
    Identity --> Orchestration[Copilot orchestration and prompt workflow]

    Orchestration --> Intake[Workbook and attachment intake]
    Intake --> Parser[Requirement extraction and normalization]
    Parser --> Matrix[Traceable requirement matrix]

    Orchestration -->     Knowledge[Approved reference library and answer catalog]
    Orchestration --> Learn[MSDN / Microsoft Learn MCP validation]
    Orchestration --> DrawIO[Draw.io MCP interactive architecture diagram]

    Matrix --> Response[Draft response, assumptions, risks and compliance notes]
    Knowledge --> Response
    Learn --> Accuracy[Accuracy register: query count, evidence, confidence, gaps]
    DrawIO --> Architecture[Interactive solution architecture: layers, flows, dependencies]

    Response --> Output[HTML / PDF / ZIP submission pack]
    Architecture --> Output
    Accuracy --> Output

    Output --> Review[SME, commercial and governance review]
    Review --> Submit[Final client submission]
"""


def build_html(summary: dict, report_title: str) -> str:
    grouped = requirement_group_rows(summary["requirements"])
    high = summary["priorities"].get("High", 0)
    medium = summary["priorities"].get("Medium", 0)
    low = summary["priorities"].get("Low", 0)
    total = summary["req_count"]
    status_summary = "<br>".join(f"{key}: {value}" for key, value in sorted(summary["status_counts"].items()))
    category_summary = "<br>".join(f"{key}: {value}" for key, value in sorted(summary["categories"].items()))

    table_rows = []
    for group in grouped[:8]:
        items = group["items"]
        rows = "".join(
            f"<tr><td>{escape(item['id'])}</td><td>{escape(item['requirement'][:160])}</td><td>{escape(item['priority'])}</td><td>{escape(item['status'])}</td></tr>"
            for item in items[:5]
        )
        table_rows.append(f"<h3>{escape(group['category'])}</h3><table><thead><tr><th>ID</th><th>Requirement</th><th>Priority</th><th>Status</th></tr></thead><tbody>{rows}</tbody></table>")

    sections = "".join(table_rows)

    return f"""<!doctype html>
<html lang="en-AU">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escape(report_title)}</title>
  <style>
    :root {{--navy:#071d49;--blue:#0067b1;--cyan:#00a8e8;--orange:#ff6b35;--ink:#172033;--muted:#607087;--bg:#f4f7fb;--card:#fff;--line:#dce5ef;--good:#11845b;--warn:#b66a00;}}
    * {{ box-sizing:border-box; }}
    html {{ scroll-behavior:smooth; }}
    body {{ margin:0; font:15px/1.6 "Segoe UI",Arial,sans-serif; color:var(--ink); background:var(--bg); }}
    a {{ color:var(--blue); }}
    .top {{ position:sticky; top:0; z-index:20; background:rgba(7,29,73,.97); color:white; display:flex; align-items:center; gap:18px; padding:10px 5vw; box-shadow:0 3px 14px #0003; flex-wrap:wrap; }}
    .brand {{ font-size:24px; font-weight:800; letter-spacing:2px; }}
    .top nav {{ display:flex; gap:8px; flex-wrap:wrap; white-space:normal; }}
    .top nav a {{ color:#eaf6ff; text-decoration:none; font-size:12px; font-weight:700; border:1px solid #ffffff30; background:#ffffff14; border-radius:999px; padding:6px 10px; line-height:1; }}
    .top nav a:hover {{ background:#ffffff28; }}
    .hero {{ min-height:480px; padding:85px 7vw 60px; color:white; background:linear-gradient(125deg,#06183d 0%,#073d78 56%,#0089c8 100%); display:grid; grid-template-columns:1.35fr .65fr; gap:45px; align-items:center; }}
    .eyebrow {{ text-transform:uppercase; letter-spacing:3px; color:#7fe2ff; font-weight:700; }}
    .hero h1 {{ font-size:clamp(38px,6vw,72px); line-height:1.04; margin:12px 0; }}
    .hero p {{ font-size:19px; max-width:750px; }}
    .meta {{ display:grid; grid-template-columns:repeat(2,1fr); gap:12px; }}
    .meta div {{ background:#ffffff16; border:1px solid #ffffff35; border-radius:13px; padding:14px; }}
    .meta b {{ display:block; color:#8ee7ff; font-size:12px; text-transform:uppercase; }}
    .score {{ background:white; color:var(--ink); border-radius:20px; padding:27px; box-shadow:0 20px 45px #00142f55; }}
    .ring {{ width:165px; height:165px; margin:auto; border-radius:50%; display:grid; place-items:center; background:conic-gradient(var(--good) 0 88%,#e5edf4 88%); }}
    .ring:after {{ content:"88%\\A GO"; white-space:pre; text-align:center; font-weight:800; font-size:26px; line-height:1.1; width:128px; height:128px; border-radius:50%; display:grid; place-items:center; background:white; }}
    .score h3 {{ text-align:center; }}
    .pill {{ display:inline-block; padding:4px 10px; border-radius:15px; background:#e7f7f1; color:var(--good); font-weight:700; }}
    main {{ max-width:1200px; margin:auto; padding:45px 24px; }}
    .section {{ margin:0 0 55px; scroll-margin-top:75px; }}
    .section h2 {{ font-size:32px; color:var(--navy); margin-bottom:8px; }}
    .section h2:after {{ content:""; display:block; width:55px; height:4px; background:var(--orange); margin-top:8px; }}
    .lead {{ font-size:18px; color:#40506a; }}
    .grid {{ display:grid; grid-template-columns:repeat(3,1fr); gap:18px; }}
    .card {{ background:var(--card); border:1px solid var(--line); border-radius:14px; padding:21px; box-shadow:0 5px 18px #16345a0b; }}
    .card h3 {{ margin-top:0; color:var(--blue); }}
    .kpi {{ font-size:30px; font-weight:800; color:var(--navy); }}
    .solution-diagram {{ background:white; border:1px solid var(--line); border-radius:18px; padding:20px; margin:22px 0; box-shadow:0 8px 24px #12345a16; overflow:hidden; }}
    .diagram-title {{ display:flex; justify-content:space-between; gap:12px; align-items:center; border-bottom:1px solid var(--line); padding-bottom:12px; margin-bottom:18px; }}
    .diagram-title b {{ color:var(--navy); font-size:18px; }}
    .diagram-badge {{ background:#e7f7f1; color:var(--good); border-radius:999px; padding:5px 10px; font-size:12px; font-weight:800; white-space:nowrap; }}
    .diagram-grid {{ display:grid; grid-template-columns:1fr 1.1fr 1.1fr 1fr; gap:14px; align-items:stretch; }}
    .diagram-lane {{ border:1px solid #dbe7f2; border-radius:15px; background:linear-gradient(180deg,#f9fcff,#eef6fc); padding:12px; min-height:255px; }}
    .diagram-lane h3 {{ margin:0 0 10px; font-size:13px; letter-spacing:.5px; color:var(--navy); text-transform:uppercase; }}
    .diagram-node {{ background:white; border:1px solid #ccddeb; border-left:5px solid var(--blue); border-radius:12px; padding:11px; margin:10px 0; box-shadow:0 3px 10px #0a31550e; }}
    .diagram-node strong {{ display:block; color:var(--navy); margin-bottom:4px; }}
    .diagram-node small {{ color:var(--muted); }}
    .diagram-node.accent {{ border-left-color:var(--orange); }}
    .diagram-node.good {{ border-left-color:var(--good); }}
    .flow-arrow {{ text-align:center; color:var(--blue); font-weight:900; font-size:24px; align-self:center; }}
    .diagram-foot {{ display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-top:16px; }}
    .diagram-foot div {{ background:#f7fbff; border:1px dashed #b9cde1; border-radius:12px; padding:11px; }}
    .accuracy-list li {{ margin-bottom:10px; }}
    .confidence-high {{ color:var(--good); font-weight:800; }}
    .confidence-pending {{ color:var(--warn); font-weight:800; }}
    table {{ width:100%; border-collapse:collapse; background:white; border-radius:12px; overflow:hidden; box-shadow:0 3px 14px #1232; margin-top:12px; }}
    th {{ background:var(--navy); color:white; text-align:left; padding:13px; }}
    td {{ padding:12px 13px; border-bottom:1px solid var(--line); vertical-align:top; }}
    tr:hover td {{ background:#f0f8ff; }}
    .notice {{ border-left:5px solid var(--warn); background:#fff6e8; padding:15px 18px; }}
    footer {{ background:var(--navy); color:#cbd9ef; padding:35px 7vw; }}
    @media(max-width:900px){{ .hero{{grid-template-columns:1fr;}} .grid{{grid-template-columns:1fr 1fr;}} .diagram-grid{{grid-template-columns:1fr;}} .flow-arrow{{transform:rotate(90deg);}} .diagram-foot{{grid-template-columns:1fr;}} }}
    @media(max-width:560px){{ .grid{{grid-template-columns:1fr;}} .meta{{grid-template-columns:1fr;}} .top{{position:static;}} .top nav a{{font-size:11px; padding:6px 8px;}} }}
  </style>
</head>
<body>
  <header class="top">
    <div class="brand">D365</div>
    <nav>
      <a href="#summary">Executive Summary</a>
      <a href="#architecture">Architecture</a>
      <a href="#coverage">Coverage</a>
      <a href="#risks">Risks</a>
      <a href="#accuracy">Accuracy</a>
      <a href="#sheets">Sheets</a>
    </nav>
  </header>
  <section class="hero">
    <div>
      <div class="eyebrow">Proposal response</div>
      <h1>{escape(report_title)}</h1>
      <p>Automated requirement extraction and response-building summary generated from the uploaded Excel workbook.</p>
      <div class="meta">
        <div><b>Workbook</b>{escape(report_title)}</div>
        <div><b>Generated</b>{escape(summary['generated_at'])}</div>
        <div><b>Requirement count</b>{total}</div>
        <div><b>Sheets</b>{len(summary['sheets'])}</div>
      </div>
    </div>
    <aside class="score">
      <div class="ring"></div>
      <h3>Recommendation: <span class="pill">GO</span></h3>
      <p><b>Priority mix:</b> {high} high / {medium} medium / {low} low</p>
      <p><b>Assessment:</b> Suitable for proposal planning subject to discovery and final solution validation.</p>
    </aside>
  </section>
  <main>
    <section id="summary" class="section">
      <h2>Executive Summary</h2>
      <p class="lead">This workbook contains {total} requirement lines across {len(summary['sheets'])} sheet(s). The requirement set is aligned to a Microsoft-based solution approach, with emphasis on security, integration, governance, delivery and user experience.</p>
      <div class="grid">
        <div class="card"><div class="kpi">{total}</div><h3>Total requirements</h3><p>All extracted items from the uploaded RFP workbook.</p></div>
        <div class="card"><div class="kpi">{high}</div><h3>High priority</h3><p>Critical items requiring early solution and dependency confirmation.</p></div>
        <div class="card"><div class="kpi">{len(summary['sheets'])}</div><h3>Source sheets</h3><p>Grouped by source sheet to support traceability.</p></div>
      </div>
    </section>

    <section id="architecture" class="section">
      <h2>Interactive solution architecture diagram</h2>
      <p class="lead">The previous static SVG architecture references have been replaced with an embedded architecture diagram. In Copilot Studio, use the configured Draw.io MCP server (<code>https://mcp.draw.io/mcp</code>) with <code>Sample Reference/Solution Architecture Template.drawio.html</code> as the visual reference, then bind the rendered Draw.io HTML/PNG diagram into this report section instead of showing Mermaid source code.</p>
      <div class="solution-diagram" role="img" aria-label="Embedded overall RFP response solution architecture diagram">
        <div class="diagram-title">
          <b>Overall RFP response solution architecture</b>
          <span class="diagram-badge">Draw.io HTML template aligned</span>
        </div>
        <div class="diagram-grid">
          <div class="diagram-lane">
            <h3>Users and channels</h3>
            <div class="diagram-node"><strong>Business users</strong><small>Upload workbook, review outputs and provide SME decisions.</small></div>
            <div class="diagram-node"><strong>Copilot Studio</strong><small>Primary authoring channel with Draw.io and Microsoft Learn MCP tools.</small></div>
            <div class="diagram-node"><strong>Review pack</strong><small>HTML/PDF/ZIP outputs for proposal and governance teams.</small></div>
          </div>
          <div class="diagram-lane">
            <h3>Orchestration and processing</h3>
            <div class="diagram-node accent"><strong>Copilot workflow</strong><small>Coordinates extraction, drafting, validation and diagram generation.</small></div>
            <div class="diagram-node"><strong>Requirement parser</strong><small>Normalizes {total} requirement line(s), source sheets and priorities.</small></div>
            <div class="diagram-node"><strong>Traceability matrix</strong><small>Links every response point back to workbook evidence.</small></div>
          </div>
          <div class="diagram-lane">
            <h3>Knowledge and validation</h3>
            <div class="diagram-node"><strong>Approved reference library</strong><small>Approved offerings, answer catalog, pricing and past performance.</small></div>
            <div class="diagram-node good"><strong>MSDN / Microsoft Learn MCP</strong><small>Validates Microsoft capability, terminology and constraints.</small></div>
            <div class="diagram-node good"><strong>Draw.io MCP</strong><small>Renders the editable architecture from the HTML template.</small></div>
          </div>
          <div class="diagram-lane">
            <h3>Outputs and governance</h3>
            <div class="diagram-node accent"><strong>Response report</strong><small>Executive summary, coverage, risks, assumptions and accuracy.</small></div>
            <div class="diagram-node"><strong>Embedded diagram</strong><small>Rendered diagram is bound inside the HTML response.</small></div>
            <div class="diagram-node"><strong>Final review</strong><small>SME, commercial and governance approval before submission.</small></div>
          </div>
        </div>
        <div class="diagram-foot">
          <div><b>Trust boundary:</b> identity, access and source evidence must be confirmed before final submission.</div>
          <div><b>Validation gate:</b> Microsoft claims require Microsoft Learn MCP evidence and confidence scoring.</div>
          <div><b>Diagram gate:</b> replace this embedded preview with the Draw.io-rendered HTML/PNG artifact when available.</div>
        </div>
      </div>
      <div class="notice"><b>Draw.io MCP instruction:</b> Use <code>Sample Reference/Solution Architecture Template.drawio.html</code> as the approved style and layout reference, render the architecture as an actual diagram, and inject/bind that diagram into this HTML section. Do not expose Mermaid source code in the final report. Return editable Draw.io content plus an HTML/PNG preview; avoid SVG output for upload compatibility.</div>
    </section>

    <section id="coverage" class="section">
      <h2>Coverage by category</h2>
      <table>
        <thead><tr><th>Category</th><th>Count</th></tr></thead>
        <tbody>
          {''.join(f'<tr><td>{escape(name)}</td><td>{value}</td></tr>' for name, value in sorted(summary['categories'].items()))}
        </tbody>
      </table>
      <div class="notice"><b>Status snapshot:</b> {status_summary}</div>
    </section>

    <section class="section">
      <h2>Requirement detail</h2>
      {sections}
    </section>

    <section id="risks" class="section">
      <h2>Risks and assumptions</h2>
      <table>
        <thead><tr><th>Area</th><th>Assessment</th></tr></thead>
        <tbody>
          <tr><td>Integration dependencies</td><td>Review system APIs, data ownership and access conditions before final response commitment.</td></tr>
          <tr><td>Security and compliance</td><td>Verify identity, data protection, hosting and audit controls against buyer requirements.</td></tr>
          <tr><td>Scope, budget and timeline</td><td>Confirm assumptions explicitly in the final response to avoid over-commitment.</td></tr>
        </tbody>
      </table>
    </section>

    <section id="accuracy" class="section">
      <h2>MSDN / Microsoft Learn accuracy register</h2>
      <p class="lead">Microsoft-specific claims in the response should be checked through the configured MSDN / Microsoft Learn MCP server in Copilot Studio before submission. The report must not imply that a Microsoft capability, limit or compliance position has been validated unless the query evidence is captured here.</p>
      <ul class="accuracy-list">
        <li><b>MSDN / Microsoft Learn MCP status:</b> <span class="confidence-pending">Pending for this generated sample</span>. This local HTML generator cannot call the Copilot Studio MCP server directly; run the validation from Copilot Studio and update this register with the query count and cited Microsoft Learn pages.</li>
        <li><b>Minimum query coverage:</b> identity and access, hosting/runtime, data integration, security/compliance, monitoring/operations, licensing and any named Microsoft product capability used in the proposed solution.</li>
        <li><b>Evidence to capture:</b> query text, Microsoft Learn page title, URL, retrieval date, claim validated, confidence level and any unresolved gap or assumption.</li>
        <li><b>Accuracy rule:</b> mark a claim <span class="confidence-high">High confidence</span> only when it is directly supported by current Microsoft Learn evidence and the workbook requirement context; otherwise mark it Medium, Low or Pending.</li>
      </ul>
      <table>
        <thead><tr><th>Validation area</th><th>Required MSDN / Microsoft Learn MCP query</th><th>Evidence status</th></tr></thead>
        <tbody>
          <tr><td>Architecture components</td><td>Confirm current Microsoft service names, roles and supported integration patterns.</td><td>Pending Copilot Studio MCP query</td></tr>
          <tr><td>Security and identity</td><td>Validate Entra ID, RBAC, authentication and audit logging statements.</td><td>Pending Copilot Studio MCP query</td></tr>
          <tr><td>Data and integration</td><td>Validate connector/API/data movement statements and any service limitations.</td><td>Pending Copilot Studio MCP query</td></tr>
          <tr><td>Operations and governance</td><td>Validate monitoring, lifecycle, environment and administrative guidance.</td><td>Pending Copilot Studio MCP query</td></tr>
        </tbody>
      </table>
    </section>

    <section id="sheets" class="section">
      <h2>Source sheets</h2>
      <table>
        <thead><tr><th>Sheet</th><th>Notes</th></tr></thead>
        <tbody>
          {''.join(f'<tr><td>{escape(sheet)}</td><td>Requirement data imported and organized for proposal drafting.</td></tr>' for sheet in summary['sheets'])}
        </tbody>
      </table>
    </section>
  </main>
  <footer>
    <div><strong>Prepared by:</strong> Proposal response team</div>
    <div><strong>Confidence:</strong> Medium, subject to discovery and validation.</div>
  </footer>
</body>
</html>
"""


def parse_args():
    parser = argparse.ArgumentParser(description="Build a D365-style HTML report from an RFP Excel workbook.")
    parser.add_argument("workbook", help="Path to the .xlsx workbook to parse")
    parser.add_argument("-o", "--output", help="Output HTML path", default="rfp_response.html")
    parser.add_argument("--title", help="Custom title for the generated report", default=None)
    return parser.parse_args()


def main():
    args = parse_args()
    workbook_path = Path(args.workbook)
    if not workbook_path.exists():
        raise SystemExit(f"Workbook not found: {workbook_path}")

    try:
        summary = extract_requirements(str(workbook_path))
    except ValueError as exc:
        raise SystemExit(str(exc))

    report_title = args.title or summary["title"]
    html = build_html(summary, report_title)
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html, encoding="utf-8")
    print(f"Generated HTML report: {out_path}")
    print(f"Requirement rows: {summary['req_count']}")
    print(f"Files and sheets included: {', '.join(summary['sheets'])}")


if __name__ == "__main__":
    main()
