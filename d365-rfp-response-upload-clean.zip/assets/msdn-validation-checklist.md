---
name: msdn-validation-checklist
description: Checklist for validating Microsoft-specific RFP response claims with the MSDN or Microsoft Learn MCP server and documenting accuracy.
---

# MSDN / Microsoft Learn MCP validation checklist

Use the MSDN / Microsoft Learn MCP server configured in Copilot Studio Tools before finalizing Microsoft-specific claims.

## Accuracy section requirements

Every generated response should include an accuracy register that states:

- Number of MSDN / Microsoft Learn MCP queries executed.
- Query topics covered.
- Microsoft Learn page titles and URLs used as evidence.
- Retrieval date.
- Claims validated.
- Confidence level for each claim.
- Open gaps, assumptions, or unresolved questions.

## Minimum query coverage

Run validation queries for every Microsoft component or claim in the response, including:

- Identity and access, such as Microsoft Entra ID, SSO, MFA, RBAC and audit logging.
- Power Platform, Copilot Studio, connector, environment and deployment statements.
- Azure hosting, API, data, integration, monitoring and security services if named.
- Licensing, limits, regional availability, compliance or operational claims.
- Any architecture diagram component that could be interpreted as a committed Microsoft capability.

## Accuracy rule

Do not mark a Microsoft-specific statement as high confidence unless it is directly supported by current Microsoft Learn evidence and the workbook requirement context. If evidence is incomplete, mark the item Medium, Low or Pending and list the follow-up required.
