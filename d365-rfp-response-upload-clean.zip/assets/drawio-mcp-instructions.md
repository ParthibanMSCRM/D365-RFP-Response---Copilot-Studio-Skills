---
name: drawio-mcp-instructions
description: Instructions for using the Draw.io MCP server and supplied Draw.io HTML template to render and inject the RFP response architecture diagram into the HTML report.
---

# Draw.io MCP architecture instructions

Use the Draw.io MCP server configured in Copilot Studio Tools at:

`https://mcp.draw.io/mcp`

## Required output

Create an editable Draw.io solution architecture diagram from `assets/solution-architecture.mmd`, using `Sample Reference/Solution Architecture Template.drawio.html` as the approved visual and layout reference. The final response HTML must show the rendered diagram, not Mermaid source code.

The diagram must be interactive and review-ready:

- Use `Sample Reference/Solution Architecture Template.drawio.html` as the reference template for visual style, grouping, layout density, diagram framing and architecture notation.
- Use swimlanes for Users/Channels, Identity, Orchestration, Requirement Processing, Knowledge & MCP Validation, Outputs, and Governance Review.
- Preserve all Mermaid nodes and connectors.
- Add clear labels for data flow, control flow, trust boundaries, and human review checkpoints.
- Add clickable notes or metadata for assumptions, open dependencies, and validation evidence.
- Export the editable Draw.io source and an HTML or PNG preview for the response pack. Do not require SVG export because SVG files may be blocked by the target upload environment.
- Bind or inject the rendered HTML/PNG diagram into the generated response HTML architecture section.
- Do not display Mermaid source code in the final user-facing report.

## Prompt to use in Copilot Studio

Create a Draw.io architecture diagram using the Mermaid source in `assets/solution-architecture.mmd` and the visual reference template `Sample Reference/Solution Architecture Template.drawio.html`. Make it an editable, interactive overall solution architecture diagram for the RFP response workflow. Preserve the template's layout style, container structure and architecture look-and-feel where appropriate, but adapt the content to this RFP workflow. Organize the diagram into clear swimlanes, show end-to-end flow from workbook intake to final submission pack, include the Draw.io MCP and MSDN / Microsoft Learn MCP validation steps, and attach notes for assumptions, evidence links, and review gates. Return editable Draw.io content and an HTML or PNG preview, then inject or bind the rendered diagram into the generated HTML report. Do not expose the Mermaid source code in the final report; avoid SVG output for upload compatibility.
