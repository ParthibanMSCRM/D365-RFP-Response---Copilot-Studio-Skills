---
name: d365-rfp-response-readme
description: Step-by-step guide for installing, configuring and using the generic D365 RFP Response Copilot package.
---

# D365 RFP Response Copilot

This is a generic RFP response helper for Dynamics 365 and Microsoft platform proposals. It helps a proposal team turn an Excel-based RFP, RFQ, RFI or tender workbook into a structured HTML response summary with requirement traceability, an embedded architecture diagram section and Microsoft Learn validation guidance.

The package is intentionally company-neutral. Add your own approved company references, case studies, pricing rules and governance wording before using it for a real client submission.

## 1. What the tool does

- Reads an uploaded Excel requirements workbook.
- Detects requirement IDs, categories, requirement text, priority, status, owner and notes.
- Groups requirements by category and source sheet.
- Generates an HTML report for review.
- Adds a visual architecture diagram section.
- Provides instructions for rendering the architecture with the Draw.io MCP server.
- Provides a Microsoft Learn / MSDN validation checklist for D365 and Microsoft platform claims.

## 2. Main components

| Component | Purpose |
| --- | --- |
| `SKILL.md` | Main Copilot skill instruction file. |
| `README.md` | Step-by-step usage guide. |
| `scripts/build_rfp_html.py` | Python generator that reads Excel and creates the HTML report. |
| `requirements.txt` | Python dependency list. |
| `assets/solution-architecture.mmd` | Baseline architecture flow for Draw.io generation. |
| `assets/drawio-mcp-instructions.md` | Draw.io MCP usage instructions. |
| `assets/msdn-validation-checklist.md` | Microsoft Learn validation checklist. |
| `Sample Reference/Solution Architecture Template.drawio.html` | Draw.io HTML architecture template. |
| `sample-rfp.xlsx` | Small sample workbook for testing. |
| `output/demo_report.html` | Example generated report. |

## 3. MCP servers used

### Draw.io MCP

Endpoint:

```text
https://mcp.draw.io/mcp
```

Use it to:

- create the editable architecture diagram
- use `Sample Reference/Solution Architecture Template.drawio.html` as the visual template
- render the actual diagram
- inject or bind the diagram into the HTML report
- avoid exposing raw Mermaid code in the final report
- avoid SVG output if the target upload environment blocks SVG files

### MSDN / Microsoft Learn MCP

Use it to validate Microsoft-specific claims, including:

- Dynamics 365 apps and capabilities
- Power Platform connectors and governance
- Copilot Studio functionality
- Microsoft Entra ID, SSO, MFA and RBAC
- Azure integration, monitoring and security services
- licensing, limits, compliance and regional availability

The report should record the number of queries, evidence links, retrieval date, confidence and open gaps.

## 4. Input required

Provide an Excel workbook, for example:

```text
Customer-RFP-Requirements.xlsx
```

Expected workbook content may include:

- requirement ID
- requirement description
- category or section
- priority or criticality
- response status
- owner
- notes or assumptions

The workbook can contain multiple sheets. The parser tries to detect the structure automatically.

## 5. Expected output

The expected output is an HTML report containing:

- executive summary
- requirement metrics
- embedded solution architecture diagram
- coverage by category
- detailed requirement matrix
- risks and assumptions
- source sheet list
- Microsoft Learn accuracy register

Optional downstream outputs may include:

- PDF export
- editable Draw.io diagram
- HTML or PNG architecture preview
- final zip response pack

## 6. Step-by-step usage in GitHub Copilot / VS Code

### Step 1 - Open the package

Open the `d365-rfp-response` folder in VS Code.

Screenshot placeholder:

```text
[Screenshot 1: VS Code opened with the d365-rfp-response folder]
```

### Step 2 - Confirm Python dependency

Install the required dependency if it is not already available:

```bash
pip install -r requirements.txt
```

Screenshot placeholder:

```text
[Screenshot 2: Terminal showing requirements installed successfully]
```

### Step 3 - Add or replace the RFP workbook

Copy the client RFP workbook into the project folder, or use the included sample:

```text
sample-rfp.xlsx
```

Screenshot placeholder:

```text
[Screenshot 3: Workbook visible in the project folder]
```

### Step 4 - Generate the HTML report

Run:

```bash
python scripts/build_rfp_html.py "sample-rfp.xlsx" -o "output/demo_report.html" --title "D365 RFP Response"
```

For a real workbook:

```bash
python scripts/build_rfp_html.py "Customer-RFP-Requirements.xlsx" -o "output/D365_RFP_Response.html" --title "D365 RFP Response"
```

Screenshot placeholder:

```text
[Screenshot 4: Terminal showing generated HTML report and requirement count]
```

### Step 5 - Open and review the report

Open the generated HTML report:

```text
output/demo_report.html
```

Check:

- requirement count
- categories
- risk and assumptions
- source sheet mapping
- architecture diagram section
- accuracy register

Screenshot placeholder:

```text
[Screenshot 5: HTML report opened in browser]
```

### Step 6 - Generate the architecture using Draw.io MCP

In Copilot Studio, confirm the Draw.io MCP server is available under Tools:

```text
https://mcp.draw.io/mcp
```

Use this instruction:

```text
Create an editable Draw.io architecture diagram using assets/solution-architecture.mmd and the visual reference template Sample Reference/Solution Architecture Template.drawio.html. Render the diagram and inject or bind the HTML/PNG output into the architecture section of the generated response report. Do not show Mermaid source code in the final report.
```

Screenshot placeholder:

```text
[Screenshot 6: Copilot Studio Tools showing Draw.io MCP configured]
```

### Step 7 - Validate Microsoft claims

Use the MSDN / Microsoft Learn MCP server to validate D365 and Microsoft platform statements.

Record:

- query count
- Microsoft Learn URLs
- retrieval date
- validated claim
- confidence
- gaps or assumptions

Screenshot placeholder:

```text
[Screenshot 7: Microsoft Learn MCP validation evidence captured]
```

### Step 8 - Prepare final response pack

Before sharing externally:

- confirm no raw Mermaid code is visible
- confirm the architecture diagram is embedded
- confirm Microsoft claims have evidence
- confirm client-specific assumptions are visible
- remove any internal-only notes
- complete SME, commercial, legal and governance review

Screenshot placeholder:

```text
[Screenshot 8: Final HTML report ready for review]
```

## 7. Upload-safe packaging rules

Do not include blocked runtime or script files in the upload zip.

Exclude:

```text
.venv/
__pycache__/
*.pyc
*.bat
*.cmd
*.ps1
*.csh
*.sh
*.exe
*.dll
*.svg
*.drawio.xml
```

Use `requirements.txt` instead of packaging a local Python virtual environment.

## 8. Important review note

This tool creates a structured first draft. It does not replace solution architect, SME, commercial, legal, security or governance review. All final claims, pricing, scope and delivery commitments must be reviewed before client submission.
