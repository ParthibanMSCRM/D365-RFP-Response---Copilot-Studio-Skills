---
name: d365-rfp-response
description: Turn an uploaded Excel-based procurement workbook into a structured Dynamics 365 RFP response summary and HTML report. Read workbook sheets, normalize requirement IDs and categories, group the requirement set, generate a submission-ready analysis, include an embedded architecture diagram, and record Microsoft Learn validation status for D365 and Microsoft platform claims.
---

# D365 RFP Response Copilot

This package is a generic GitHub Copilot / Copilot Studio helper for creating first-draft Dynamics 365 RFP response material from an uploaded procurement workbook.

It is not tied to a specific company brand. It should be adapted by each proposal team with its own approved references, commercial assumptions, legal wording and delivery methodology.

## What this tool does

- Reads an Excel RFP, RFQ, RFI, tender or requirements workbook.
- Detects common requirement columns such as ID, category, requirement text, priority, status, owner and notes.
- Groups the requirement set into a traceable response matrix.
- Generates a clean HTML response report.
- Includes an embedded solution architecture diagram section.
- Uses the Draw.io MCP server instructions to create a proper editable diagram from the supplied Draw.io HTML template.
- Uses the MSDN / Microsoft Learn MCP validation checklist to verify Microsoft-specific claims before final submission.

## What to read first

- `README.md` - setup, usage steps, screenshot placeholders and expected inputs/outputs.
- `SKILL.md` - this skill definition and operating workflow.
- `scripts/build_rfp_html.py` - Excel-to-HTML report generator.
- `assets/solution-architecture.mmd` - baseline architecture flow used as source material for Draw.io.
- `assets/drawio-mcp-instructions.md` - instructions for using the Draw.io MCP server at `https://mcp.draw.io/mcp`.
- `assets/msdn-validation-checklist.md` - accuracy and Microsoft Learn validation checklist.
- `Sample Reference/Solution Architecture Template.drawio.html` - approved Draw.io HTML architecture template.

## Expected input

Upload an Excel workbook with one or more sheets. Typical sheets may include:

- Requirements
- Functional specification
- Non-functional requirements
- Security and compliance
- Integration requirements
- Data migration
- Reporting and analytics
- Licensing and support
- Pricing
- Evaluation criteria

The workbook can use different column names. The parser attempts to detect common labels such as:

- requirement ID / item / reference / code
- category / section / domain / group
- requirement / description / question / details
- priority / criticality / importance / impact
- status / response status / completion
- owner / responsible team
- notes / assumptions / comments

## Workflow

### 1. Understand and normalize the workbook

The parser should:

- Remove blank rows.
- Keep source sheet names for traceability.
- Preserve requirement IDs and labels where available.
- Group records by category or section.
- Flag priority as High, Medium, Low or Unspecified.
- Summarize status counts across the workbook.

### 2. Generate the HTML response report

The HTML output should include:

- branded-neutral header and hero section
- executive summary
- summary metrics
- embedded solution architecture diagram
- coverage by category
- requirement detail by category
- risks and assumptions
- source sheet list
- MSDN / Microsoft Learn accuracy register

### 3. Generate and embed the architecture diagram

Use the Draw.io MCP server configured in Copilot Studio Tools:

- MCP endpoint: `https://mcp.draw.io/mcp`
- Source file baseline: `assets/solution-architecture.mmd`
- Visual reference template: `Sample Reference/Solution Architecture Template.drawio.html`
- Required output: editable Draw.io diagram plus HTML/PNG preview embedded or linked in the generated report

The final report must show a diagram, not raw Mermaid code. If the Draw.io MCP call has not yet been run, use the generated HTML/CSS preview diagram and label it as a preview pending Draw.io MCP rendering.

The diagram should include:

- business users and proposal reviewers
- GitHub Copilot / Copilot Studio authoring flow
- workbook intake
- requirement extraction and traceability
- approved response knowledge base
- Draw.io MCP rendering
- MSDN / Microsoft Learn MCP validation
- HTML/PDF/ZIP output pack
- SME, commercial and governance review

Avoid SVG output in the upload bundle because SVG files may be blocked by some environments.

### 4. Validate Microsoft and D365 claims

When the response mentions Dynamics 365, Power Platform, Copilot Studio, Azure, Microsoft Entra ID, connectors, licensing, governance, limits, regional availability, compliance or any Microsoft product capability, validate those statements through the MSDN / Microsoft Learn MCP server configured in Copilot Studio Tools.

The response must include an accuracy register stating:

- how many MSDN / Microsoft Learn MCP queries were executed
- which topics were queried
- which Microsoft Learn pages or evidence were used
- the retrieval date
- which claims were validated
- confidence level for each claim
- unresolved gaps, assumptions or follow-up items

If MCP validation has not been executed, say so explicitly. Do not imply that Microsoft claims are authoritative without captured evidence.

### 5. Keep assumptions explicit

If the workbook is incomplete, ambiguous or missing sections, treat those as follow-up items rather than inventing commitments.

Examples:

- "Need client confirmation on target Dynamics 365 apps and licensed users."
- "Need integration API access before final integration scope and pricing are confirmed."
- "Need final procurement weighting and scoring model before response prioritization is locked."

### 6. Validate before handoff

Before finishing, confirm that:

- the workbook was read successfully
- requirement rows were detected and grouped
- the generated HTML file was created
- the requirement count is consistent with the workbook
- the architecture section contains a visual diagram preview or rendered Draw.io output
- the accuracy register reflects actual Microsoft Learn validation status
- no blocked upload file types are included in the zip

## Command usage

Generate the HTML report from an Excel workbook:

```bash
python scripts/build_rfp_html.py "C:/path/to/rfp.xlsx" -o "output/D365_RFP_Response.html" --title "D365 RFP Response"
```

If the workbook is in the project folder:

```bash
python scripts/build_rfp_html.py "sample-rfp.xlsx" -o "output/demo_report.html"
```

## Expected outcome

The user should be able to upload an RFP workbook and receive a structured, readable Dynamics 365 response report with requirement traceability, architecture, assumptions, risks and Microsoft Learn validation status.
